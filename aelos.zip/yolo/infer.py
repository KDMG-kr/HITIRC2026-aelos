# infer_image_no_ui.py
import cv2
import json
import time
from ultralytics import YOLO

MODEL_PATH = "/home/zhangjiahao/yolo/runs/detect/runs/yolov8n_finetune/weights/best.pt"
IMAGE_PATH = "image2.jpg"          
OUTPUT_IMAGE_PATH = "result2.jpg"  
TARGET_CLASS_NAME = "handler"
CONF_THRES = 0.5
IMG_SIZE = 640
DEVICE = 0
PRINT_NO_DETECTION = False

def main():
    # 加载模型
    model = YOLO(MODEL_PATH)
    names = model.names

    print("模型类别：", names)

    # 读取本地图片
    frame = cv2.imread(IMAGE_PATH)
    if frame is None:
        raise RuntimeError(f"无法读取图片 {IMAGE_PATH}，请检查文件是否存在或格式是否正确。")

    frame_id = 0
    prev_time = time.time()

    # 推理
    results = model.predict(
        source=frame,
        conf=CONF_THRES,
        imgsz=IMG_SIZE,
        device=DEVICE,
        verbose=False
    )

    result = results[0]
    boxes = result.boxes

    detections = []

    if boxes is not None and len(boxes) > 0:
        xyxy_list = boxes.xyxy.cpu().numpy()
        conf_list = boxes.conf.cpu().numpy()
        cls_list = boxes.cls.cpu().numpy().astype(int)

        for xyxy, conf, cls_id in zip(xyxy_list, conf_list, cls_list):
            class_name = names.get(cls_id, str(cls_id))

            if class_name != TARGET_CLASS_NAME:
                continue

            x1, y1, x2, y2 = map(int, xyxy.tolist())
            cx = int((x1 + x2) / 2)
            cy = int((y1 + y2) / 2)
            w = x2 - x1
            h = y2 - y1

            det = {
                "frame_id": frame_id,
                "class_name": class_name,
                "confidence": round(float(conf), 4),
                "bbox_xyxy": [x1, y1, x2, y2],
                "center_xy": [cx, cy],
                "width_height": [w, h]
            }
            detections.append(det)

            # 绘制检测框和文字
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            label = f"{class_name} {conf:.2f}"
            cv2.putText(
                frame,
                label,
                (x1, max(y1 - 10, 20)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 0),
                2
            )
            cv2.circle(frame, (cx, cy), 4, (0, 0, 255), -1)
            coord_text = f"({x1},{y1}) ({x2},{y2})"
            cv2.putText(
                frame,
                coord_text,
                (x1, min(y2 + 25, frame.shape[0] - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 0, 0),
                2
            )

    print(json.dumps(detections, ensure_ascii=False))

    # 将结果图片保存到文件
    cv2.imwrite(OUTPUT_IMAGE_PATH, frame)
    print(f"标注后的图片已保存为: {OUTPUT_IMAGE_PATH}")

if __name__ == "__main__":
    main()