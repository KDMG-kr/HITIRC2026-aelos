# train.py

from ultralytics import YOLO
from pathlib import Path

def main():
    #数据集路径配置 
    data_yaml = "data.yaml"   
    #加载缓存好的模型
    model = YOLO("yolov8n.pt")

    #训练阶段
    results = model.train(
        data=data_yaml,
        epochs=100,          
        imgsz=640,           
        batch=4,             
        workers=2,           
        cache=False,         
        device=0,           
        project="runs",
        name="yolov8n_finetune",
        exist_ok=True,
        pretrained=True,     
        optimizer="auto",
        patience=30,         
        save=True,
        verbose=True
    )
    print(f"训练结果: {results}")

    # 验证阶段
    metrics = model.val()
    print(metrics)

    #保存best.pt路径
    best_pt = Path("runs/train/yolov8n_finetune/weights/best.pt")
    last_pt = Path("runs/train/yolov8n_finetune/weights/last.pt")
    print(f"best.pt exists: {best_pt.exists()} -> {best_pt}")
    print(f"last.pt exists: {last_pt.exists()} -> {last_pt}")
if __name__ == "__main__":
    main()