import cv2
import numpy as np
import matplotlib.pyplot as plt

#读取图像
image_path = "image.png"  
img = cv2.imread(image_path)

# 从RGB更改为HSV
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

#定义两段颜色范围
lower_red1 = np.array([0, 80, 50])
upper_red1 = np.array([10, 255, 255])

lower_red2 = np.array([170, 80, 50])
upper_red2 = np.array([180, 255, 255])

#生成对应的掩码
mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
mask = cv2.bitwise_or(mask1, mask2)

#去噪
kernel = np.ones((5, 5), np.uint8)
mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

# 查找轮廓
contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

if len(contours) == 0:
    print("未检测到红色目标")
else:
    # 取面积最大的轮廓
    cnt = max(contours, key=cv2.contourArea)

    # 外接矩形
    x, y, w, h = cv2.boundingRect(cnt)

    # 质心坐标
    M = cv2.moments(cnt)
    if M["m00"] != 0:
        cx = int(M["m10"] / M["m00"])
        cy = int(M["m01"] / M["m00"])
    else:
        cx, cy = x + w // 2, y + h // 2

    print("检测结果：")
    print(f"外接矩形左上角坐标: ({x}, {y})")
    print(f"外接矩形宽高: ({w}, {h})")
    print(f"中心坐标: ({cx}, {cy})")

    #绘制识别结果
    result = img.copy()
    cv2.rectangle(result, (x, y), (x + w, y + h), (0, 255, 0), 2)
    cv2.circle(result, (cx, cy), 4, (255, 0, 0), -1)
    cv2.putText(result, f"center=({cx},{cy})", (x - 20, y - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    cv2.putText(result, f"bbox=({x},{y},{w},{h})", (x - 20, y + h + 25),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    #显示原图、掩码图、识别图
    plt.figure(figsize=(12, 4))

    plt.subplot(1, 2,1)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.title("Original")
    plt.axis("off")

    plt.subplot(1, 2, 2)
    plt.imshow(cv2.cvtColor(result, cv2.COLOR_BGR2RGB))
    plt.title("Detection Result")
    plt.axis("off")

    plt.tight_layout()
    plt.show()

    #保存结果图
    cv2.imwrite("detected_result.jpg", result)
    cv2.imwrite("mask.jpg", mask)