#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import cv2
import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

class ImagePublisher:
    def __init__(self):
        rospy.init_node('img_pub', anonymous=True)

        self.bridge = CvBridge()
        self.pub = rospy.Publisher('/image_raw', Image, queue_size=1)

        # 读取同目录下的 image.png
        script_dir = os.path.dirname(os.path.abspath(__file__))
        default_path = os.path.join(script_dir, 'image.png')
        self.image_path = rospy.get_param('~image_path', default_path)

        self.rate = rospy.Rate(1)  # 1Hz，反复发布同一张图

        self.image = cv2.imread(self.image_path)

        rospy.loginfo("开始发布话题: /image_raw")

    def run(self):
        while not rospy.is_shutdown():
            msg = self.bridge.cv2_to_imgmsg(self.image, encoding='bgr8')
            msg.header.stamp = rospy.Time.now()
            msg.header.frame_id = 'image_frame'
            self.pub.publish(msg)
            self.rate.sleep()

if __name__ == '__main__':
    node = ImagePublisher()
    node.run()